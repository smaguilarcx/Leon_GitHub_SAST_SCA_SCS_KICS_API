import { whatWeWant } from './index.js';
console.log(whatwewant);