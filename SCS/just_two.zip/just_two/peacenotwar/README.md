# peacenotwar

This code serves as a non-destructive example of why controlling your node modules is important. It also serves as a non-violent protest against Russia's aggression that threatens the world right now. This module will add a message of peace on your users' desktops, and it will only do it if it does not already exist just to be polite.

To include this module in your code, just run `npm i peacenotwar` in your code's directory or module root. ***Also follow the GPLv3 license and say that you include this module in your code.***

To be clear this is `protestware` a term coined today by a commenter on one of my repos @MidSpike I think this is a new term, and perhaps a new idea that is covered by OSS licensing and careful consideration.

In your main file simply include the module :


#### ES6 Example useage

```js

import { whatWeWant } from 'peacenotwar';

console.log(whatWeWant);

```

see the example in `test.js`


#### ES5 / CJS Example useage

```js

var peacenotwar=require('./index.cjs');
console.log(peacenotwar.whatWeWant);

```

[![Sponsor RIAEvangelist to help development of node-ipc](https://img.shields.io/static/v1?label=Sponsor%20Me%20On%20Github&message=%E2%9D%A4&logo=GitHub&link=https://github.com/sponsors/RIAEvangelist)](https://github.com/sponsors/RIAEvangelist)


War is not the answer, no matter how bad it is. Please stand up against this injustice and stand up against evil. Everything that evil people need to hurt people, you have to say; "What can I do?" You are one person. It's powerful. When one person is standing next to another and they are standing next to another, you soon have movement. Here's how little people can come together for more than one person. Do what you think is right, follow your own morals.

May God bless you and your family. Stay safe.

[One Day Official Music Video](https://www.youtube.com/watch?v=WRmBChQjZPs)

One day
Mattisyahu

Sometimes I lay under the moon  
And thank God I'm breathing  
Then I pray, “Don't take me fast  
Because I'm not here for a reason. "  
Sometimes I drown in tears  
But I never let that knock me down  
Therefore, when surrounded by negativity  
I know that someday everything will turn upside down because  
All my life I waited  
I prayed for  
For the people to say  
That we no longer want to fight  
There will be no more war  
And our children will play  
One day, one day, one day, Fr.  
One day, one day, one day, Fr.  
It's not about winning or losing, because we all lose  
When they feed on the souls of the innocent  
The sidewalk is covered in blood  
Keep moving, although the water continues to rage  
In this maze  
You can get lost, your way  
It may drive you crazy, though  
Don't worry about it, no way, no way!  
Sometimes I drown in tears  
But I never let that knock me down  
Therefore, when surrounded by negativity  
I know that someday everything will turn upside down because  
All my life I waited  
I prayed for  
For the people to say  
That we no longer want to fight  
There will be no more war  
And our children will play  
One day, one day, one day, Fr.  
One day, one day, one day, Fr.  
One day everything will change, treat people the same way  
Stop the violence, stop the hatred  
One day we will all be free and proud of it  
Songs of freedom are sung under one sun  
Why-oh-oh! (One day, one day) why-oh, oh, oh!  
Why-oh-oh! (One day, one day) why-oh, oh, oh!  
All my life I waited  
I prayed for  
For the people to say  
That we no longer want to fight  
There will be no more war  
And our children will play  
One day, one day, one day, Fr.  
One day, one day, one day, Fr.  
