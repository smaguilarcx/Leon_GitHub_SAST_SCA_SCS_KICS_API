var peacenotwar=require('./index.cjs');
console.log(peacenotwar.whatWeWant);